"use strict";

      var map;
      function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -51.0603117, lng: 3.7101227},
          zoom: 8
        });
      }


    